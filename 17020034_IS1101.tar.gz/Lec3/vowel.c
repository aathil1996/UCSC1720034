#include <stdio.h>
int main() {
    char c;
    int isLowercaseVowel, isUppercaseVowel;

    printf("Enter an alphabet: (1 mean TRUE 0 mean FALSE) ");
    scanf("%c",&c);

    // evaluates to 1 (true) if c is a lowercase vowel
    isLowercaseVowel = (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u');
	

    // evaluates to 1 (true) if c is an uppercase vowel
    isUppercaseVowel = (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U');
	

    // evaluates to 1 (true) if either isLowercaseVowel or isUppercaseVowel is true
   (isLowercaseVowel || isUppercaseVowel) == (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u'||c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U');
	//print true or false
	printf("is %c vowel? %d ", c,(isLowercaseVowel || isUppercaseVowel));
   return 0;
}
