#include <stdio.h>

void reverse();

int main(){
 printf("Enter the sentense :");
 reverse();
 printf("\n");
}

void reverse(){
	char ch;
	scanf("%c",&ch);
	if (ch!='\n') 
	{ 	reverse();
		printf("%c",ch);
	}

}
