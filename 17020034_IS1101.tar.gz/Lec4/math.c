#include <stdio.h>
#define f(n) (n/3.0+2)

int main(){
 int n=5;
 printf("%f\n",f(n));
 return 0;
}
