#include <stdio.h>

#define PI 3.14
#define circleArea(r) (PI*r*r)


int main(){ 

 int radi;
	printf("Enter the radius of cilinder:\n");
	scanf("%d", &radi);

	printf("Area of the Circle = %.2f \n",circleArea(r));
 return 0;
}
