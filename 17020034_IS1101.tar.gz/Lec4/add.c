#include <stdio.h>

int addNumbers(int,int);

int main(){
	
 	int a,b,c;
	 printf("Enter First Number :");
 	scanf("%d",&a);
	
	printf("Enter second Number :");
 	scanf("%d",&b);

	 c=addNumbers(a,b);
 	printf("%d + %d = %d \n",a,b,c);
	 return 0;
	}

	int addNumbers(int x, int y){
 	return x+y;
}

