#include <stdio.h>

#define wage (40*150)
#define OT (20*75)



int main(){

	int income = wage + OT;
	float Tax = income/100*10;
	int salary = income - Tax;

	printf ("take home salary is Rs.%d\n", salary);
	return 0;
}

	
