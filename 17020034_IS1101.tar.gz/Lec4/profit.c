#include <stdio.h>

#define profit(price) (revenue(price)-cost(price))

#define revenue(price) (price*attendees(price))

#define cost(price) (500+3*attendees(price))

#define attendees(price) ((((15-price)/5)*20)+120)

int main(){
 int price=25;
 printf("Ticket Price = %d => profit = %d\n",price,profit(price));
 return 0;
}
