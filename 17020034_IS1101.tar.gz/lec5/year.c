#include<stdio.h>
int leap(int);
int daysInMonth(int,int);

int main(){
int year=0,month=0;
  //Need to continue it till someone enter negative value
  // for year or month
while(year>=0&&month>=0)
{
  printf("Enter Year and Month:");
  scanf("%d %d",&year,&month);
  if(leap(year)) printf("%d is leap year.\n",year);
  else printf("%d is not leap year. \n",year);

  printf("%d days in %d / %d\n",daysInMonth(year,month),month,year);
 }
return 0; 
}

int daysInMonth(int year,int n){
 int days=0;
 switch(n){
   case 1:
   case 3:
   case 5:
   case 7:
   case 8:
   case 10: 
   case 12:
	days=31;
	break;
   case 2:
	if (leap(year)) days=29;
	else days=28;
	break;	
   case 4:
   case 6:
   case 9:
   case 11:
	days=30;
	break;
 }
 return days;
}

int leap(int year) {
  int true=1;

  if (year%4!=0) true=0;
  else if (year%100==0 && year%400!=0) true=0;
  else true=1;
  return true;
}

