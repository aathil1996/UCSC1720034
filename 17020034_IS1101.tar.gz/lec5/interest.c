#include <stdio.h>

double rate(double amount);
double interest(double amount);

int main(){
	double amount=0;
 	printf("Enter amount : ");
 	scanf("%lf",&amount);
	printf("The interest at %lf percent is %lf\n",(rate(amount)*100),interest(amount));
	return 0;
}

double rate(double amount){
if (amount<=10000) return.04;
else if (amount<=100000) return .05;
else if (amount<=1000000) return .1;
else return .15;
}

double interest(double amount){
	return amount*rate(amount);
}
