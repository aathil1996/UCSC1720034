#include <stdio.h>

int prime(int n);

int main(){
 int n=0;
 printf("Enter a Number :");
 scanf("%d",&n);

 if(prime(n)) printf("%d is a prime number. \n",n);
 else printf("%d is not a prime number. \n",n);
 return 0;
}

int prime(int n){
	int i,j=0;
	for(i=1;i<=n;i++){
	if (n%i==0){ 
		j++; 
		}
	}
if(j==2) {return 1;}
else {return 0;}
	
}
