#include <stdio.h>
int reverse(int number);
int main()
{
	int number;
	printf("Input number: ");
	scanf("%d",&number);
	reverse(number);
}

int reverse(int number){
	int i,j;
	while(number>1){
		printf("%d",number%10);
		number=number/10;
	}
		printf("\n");
}
