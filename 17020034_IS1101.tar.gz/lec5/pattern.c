#include <stdio.h>

void pattern(int);

int main(){
 pattern(4);
}

void pattern(int n){
	int i,j;
	for(j=1;j<=n;j++){
	for(i=1;i<=j;i++){
		printf("*");
	}
	printf("\n");
}
	return;
}
