#include <stdio.h>
int main(){
  int n, i,j;
  printf("Enter an integer: ");
  scanf("%d",&n);
 //Print multification table here
	for(i=1;i<=12;i++){
		j=i*n;
		printf("%d x %d=%d\n",n,i,j);
	}
return 0;
}
