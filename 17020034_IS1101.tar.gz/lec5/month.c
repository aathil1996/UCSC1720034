int leap(int);

int daysInMonth(int year,int n){
 int days=0;
 switch(n){
   case 1:
   case 3:
   case 5:
   case 7:
   case 9:
   case 2: 
   case 4:
   case 6:
   case 8:
   case 10:
   case 12:
 }
 return days;
}

