#include <stdio.h>

int main(){
	int i=0,n,sum=0;
	printf("Input number : ");
	scanf("%d",&n);
	while (n>=i){
		sum =sum+i;
		i++;
	}


	printf("Sum %d \n",sum);
}
