#include <stdio.h>

int main(){
 int a=10,b=12,c=0;

 c=a++;
 --b;
 printf("a= %d b=%d c=%d \n",a,b,c);
 return 0;
}
