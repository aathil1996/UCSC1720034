#include <stdio.h>

#define pi 3.14
int main(){
 
 float r,area;
 printf("Enter radius : ");

 scanf("%f",&r);

 area=pi*r*r;

 printf("R= %f Area = %.2f \n",r,area);
 return 0;
}
