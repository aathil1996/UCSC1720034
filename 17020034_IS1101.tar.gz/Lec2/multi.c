#include <stdio.h>
int main() {
	
 float firstNumber, secondNumber, answer;

 	printf("Enter first number: ");
 	scanf("%f",&firstNumber);
	
	printf("Enter Second number: ");
	scanf("%f",&secondNumber);
  // multiply two numbers in stored in variable answer
 	
	answer=firstNumber*secondNumber;
 // Displays the answer
 	 printf("Answer = %.2f \n",answer);
  	return 0;

}
