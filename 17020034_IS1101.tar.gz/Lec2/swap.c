#include <stdio.h>
int main() {

 double firstNumber, secondNumber, temporaryVariable;

	//%lf is used for double
 	//scan first number
 	printf("Enter first number: ");
	 scanf("%lf", &firstNumber);
	//scan first number
	 printf("Enter second number: ");
	 scanf("%lf",&secondNumber);

	//Swap two numbers	 
	temporaryVariable=firstNumber;
	 firstNumber=secondNumber;
	 secondNumber=temporaryVariable;
 	
 
	 printf("\nAfter swapping, firstNumber = %.2lf\n", firstNumber);
 	printf("After swapping, secondNumber = %.2lf\n", secondNumber);
       
 	 return 0;
}
