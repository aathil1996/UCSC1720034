#include <stdio.h>

int main() {
 const char name[20] = Inthu;

	 /*printf("Enter name: ");
	
	 scanf("%s", name);*/
	
	printf("This is your name: %s \n", name);
 return 0;
}
