#include <stdio.h>
int main() {
 char ch;

 	printf("Enter a character: \n");
 	//Read the character
	 scanf("%c", &ch);
	//Read and print the character
	printf("This is your character: %c \n", ch);
	
 return 0;
}
