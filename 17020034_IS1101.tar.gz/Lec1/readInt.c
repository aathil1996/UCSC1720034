#include <stdio.h>
int main() {
 int testInteger;
	        
 printf("Enter an integer: ");
 	//Read the integer
	 scanf("%d", &testInteger);
	//Print the integer
	printf("This is your integer: %d \n",testInteger);
	
 return 0;
}
