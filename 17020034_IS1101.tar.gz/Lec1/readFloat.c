#include <stdio.h>
int main() {
 float testNumber;
	        
 printf("Enter a number: ");
	//Read the float
	 scanf("%f", &testNumber);
	//Print the float
	printf("This is your float:%.2f \n", testNumber);
 return 0;
}
