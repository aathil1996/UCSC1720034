#include <stdio.h>
int main() {

 int testInteger = 5;

 printf("This is your Integer: %d \n",testInteger); 
 return 0;
}
